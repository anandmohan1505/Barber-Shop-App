package com.job.barbershop.payment

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.job.barbershop.R

class PayDoneActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pay_done)
    }
}
