package com.job.barbershop.util

object Constants {

    const val PREF_FIRST_RUN = "PREF_FIRST_RUN"



}
